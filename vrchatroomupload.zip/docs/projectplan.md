# Projektplan – Pratrummet

## Läge just nu

v1.3 är byggd och fungerar i grunden: karaktärsskapare, tre världar, multiplayer via PeerJS, textchatt, emotes, VR, platt läge och pekskärm. Men rumskoden är opålitlig i tre situationer, vilket i praktiken blockerar multiplayer.

## Fas 1 – Rumskoden ska alltid funka

- [ ] Utred varför koden ofta inte visas vid rumsskapande (nätverksberoende UI?)
- [ ] Visa koden direkt när rummet skapas, oberoende av nätverksstatus
- [ ] Se till att koden syns i VR-HUD:en under hela sessionen
- [ ] Överlev att mobilen läggs ner: hantera visibilitychange, återanslut och visa koden igen
- [ ] Testa hela flödet: skapa rum på dator, gå med från mobil, gå in och ur VR, lägg ner mobilen och ta upp den

## Fas 2 – Snyggare och skönare

- [ ] Animationer: idle, mjukare gång, huvud och armar
- [ ] Material och texturer i världarna, procedurellt utan externa filer
- [ ] Ljud- och UI-polish

## Fas 3 – Verifiering

- [ ] Testa på Quest (VR in och ut flera gånger)
- [ ] Testa på mobil (bakgrund och förgrund flera gånger)
- [ ] Testa på dator (muslås, chatt, emotes)
- [ ] Uppdatera README, CHANGELOG, LESSONS
