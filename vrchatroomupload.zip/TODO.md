# TODO – Pratrummet

Arbetslista för nästa omgång. Buggarna först, sedan förbättringar.

## Buggar (prio 1)

- [ ] **Rumskoden dyker ofta inte upp när man skapar rum.** Rummet skapas men koden visas inte, så ingen kan gå med. Trolig koppling till PeerJS-uppkopplingen (se LESSONS #4). Koden måste alltid visas, även om nätverket är segt, och statusen ska stå i klartext.
- [ ] **VR: rumskoden försvinner när man går in i faktisk VR.** Koden syns i platt läge men är borta så fort VR-sessionen startar. Handleds-HUD:en ska alltid visa aktuell rumskod.
- [ ] **Mobil: rumskoden försvinner när man lägger ner mobilen.** Troligen tappas peer-anslutningen eller state när sidan blir dold (visibilitychange/sidsuspendering). Koden och anslutningen ska överleva att skärmen släcks eller appen läggs i bakgrunden, eller återställas snyggt när man kommer tillbaka.

## Förbättringar (prio 2)

- [ ] Bättre animationer: mjukare gång, idle-rörelser, naturligare armar och huvud
- [ ] Bättre texturer och material i alla tre världar (fortfarande utan externa filer, procedurellt eller inbäddat)
- [ ] Allmän polish: ljud, ljus, UI-känsla, övergångar

## Regler

- Allt ska fortsatt ligga i en enda HTML-fil utan byggsteg
- Three.js r128 är låst av kravspecen, se LESSONS #1
- Prestandakraven för Quest 2 i README gäller (exakt tre ljuskällor, InstancedMesh, inga skuggkartor)
- Läs LESSONS.md innan felsökning, uppdatera den med nya lärdomar
- Logga alla ändringar i CHANGELOG.md och bumpa versionen som visas i UI:t
